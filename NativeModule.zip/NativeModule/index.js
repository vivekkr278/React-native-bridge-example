
import { NativeModules } from 'react-native';

const { RNNativeModule } = NativeModules;

export default RNNativeModule;
